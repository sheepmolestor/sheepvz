const socket = io("ws://25.36.62.158:3000/");

socket.on("connect", ()=>{
	console.log("we shilling");
});

socket.on('plant', (x,y) => {
	spawnPlant(x,y);
	console.log("solobolo");
});
var ready = false;

var time=0;
socket.on('done', (t) => {
	ready = true;
	time=t;
	//console.log(t);
})





const app = new PIXI.Application({ antialias: true });
const loader = new PIXI.Loader();

document.body.appendChild(app.view);

const graphics = new PIXI.Graphics();

const GRID_WIDTH=9;
const GRID_HEIGHT=8;

app.stage.addChild(graphics);

let cat, state;

let grid = [];
for (i = 0; i<GRID_WIDTH; i++) {
	var temp = [];
	for (j=0; j<GRID_HEIGHT; j++) {
		temp.push(0);
	}
	grid.push(temp);
}
let enemies = [];

let projectiles = [];

	document.addEventListener('keypress', (event) => {
	  var name = event.key;
	  var code = event.code;
	  // Alert the key name and key code on keydown
	  //alert(`Key pressed ${name} \r\n Key code value: ${code}`);
	  spawnZombie();
	}, false);

  let squareWidth = app.screen.width/GRID_WIDTH;
	let squareHeight = app.screen.height/GRID_HEIGHT*0.8;

	document.addEventListener('mouseup', (event) => {
		var x = Math.floor(event.offsetX/squareWidth);
		var y = Math.floor(event.offsetY/squareHeight);
		console.log(x+" "+y);
		if (x<GRID_WIDTH&&y<GRID_HEIGHT){
			sendPlant(x,y);
		}
	}, false);

  //Set the game state
  state = play;
 	
  //Start the game loop 
  app.ticker.add(delta => gameLoop(delta));
  // ok but like tick length could be desynced...


function gameLoop(delta){

  //Update the current game state:
  if (ready) {
  	state(delta);
  	ready = false;
  }
  render();
  //console.log(app.ticker.deltaMS);
  socket.emit('done',socket.id,app.ticker.deltaMS);
}

function play(delta) {

  for (i in enemies) {
  	enemies[i].dist+=enemies[i].speed*time/1000;//app.ticker.deltaMS/1000;
  	if (enemies[i].dist>GRID_WIDTH||enemies[i].hp<=0) {
  		enemies.splice(i,1);
  	}
  }
  for (i in grid) {
  	for (j in grid[i]) {
  		if (grid[i][j]!=0) {
  			if (grid[i][j].timer<=0) {
	  			for (k in enemies) {
	  				if (enemies[k].lane==j&&(GRID_WIDTH-0.5-enemies[k].dist)>i) {
	  					grid[i][j].shoot();
	  					grid[i][j].timer = grid[i][j].rate;
	  					break;
	  				}
	  			}
  			} else {
  				grid[i][j].timer-=time/1000;//app.ticker.deltaMS/1000;
  			}
  		}
  	}
  }
  for (i in projectiles) {
  	projectiles[i].dist+=projectiles[i].speed*time/1000;//app.ticker.deltaMS/1000;
  	if (projectiles[i].dist+projectiles[i].home+0.5>GRID_WIDTH) {
  		projectiles.splice(i,1);
  	} else {
	  	for (j in enemies) {
	  		if (enemies[j].lane==projectiles[i].lane&&Math.abs(projectiles[i].home+projectiles[i].dist-(GRID_WIDTH-0.5-enemies[j].dist))<(1/4+1/8)) { //hit(projectiles[i],enemies[j])
	  			
	  			enemies[j].hp-=projectiles[i].damage;
	  			projectiles.splice(i,1);
	  			break;
	  		}
	  	}
  	}
  }
}

function render() {
	
	graphics.clear();
	for (i=0; i<GRID_WIDTH; i++) {
		for (j=0; j<GRID_HEIGHT; j++) {
			graphics.lineStyle(2,0x000000);
			graphics.beginFill(0xFFFFFF);
			graphics.drawRect(i*squareWidth, j*squareHeight, squareWidth, squareHeight);
			graphics.endFill();
		}
	}
	for (i in grid) {
		for (j in grid[i]) {
			if (grid[i][j]!=0) {
				graphics.lineStyle(2,0x000000);
				graphics.beginFill(0x0000FF);
				graphics.drawCircle(squareWidth/2+i*squareWidth,squareHeight/2+j*squareHeight,squareWidth/4);
			}
		}
	}
	enemies.reverse();
	for (i in enemies) {
		graphics.lineStyle(2,0x000000);
		graphics.beginFill(0x00FF00);
		graphics.drawCircle(squareWidth*GRID_WIDTH-enemies[i].dist*squareWidth,squareHeight/2+squareHeight*enemies[i].lane,squareWidth/4);
	}
	enemies.reverse();

	projectiles.reverse();
	for (i in projectiles) {
		graphics.lineStyle(2,0x000000);
		graphics.beginFill(0xFF0000);
		graphics.drawCircle(projectiles[i].home*squareWidth+squareWidth/2+projectiles[i].dist*squareWidth,squareHeight/2+squareHeight*projectiles[i].lane,squareWidth/8);
	}
	projectiles.reverse();
	
}

function spawnZombie() {
	enemies.push({
		hp: 200,
		speed: 1/5,
		lane: Math.floor(Math.random()*GRID_HEIGHT),
		dist: 0,
	});
}

function spawnPlant(x,y) {
	grid[x][y] = {
		hp:200,
		damage:20,
		rate:1,
		timer:0,
		shoot: () => {
			projectiles.push({
				speed: 1.5,
				home: x,
				lane: y,
				damage: 20,
				dist: 0,
			});
		},
	};
}

function sendPlant(x,y) {
	socket.emit('plant',x,y);
}